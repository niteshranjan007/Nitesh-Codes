package com.beingjavaguys.domain;

public class Student {
	
	private String yearCreated;
	private Integer ideasSubmitted;
	private Integer solvedIn2014A;
	private Integer closededIn2014A;
	private Integer duplicateIn2014A;
	private Integer solvedIn2014B;
	private Integer closededIn2014B;
	private Integer duplicateIn2014B;
	private Integer solvedIn2014C;
	private Integer closededIn2014C;
	private Integer duplicateIn2014C;
	
	public String getYearCreated() {
		return yearCreated;
	}
	public void setYearCreated(String yearCreated) {
		this.yearCreated = yearCreated;
	}
	public Integer getIdeasSubmitted() {
		return ideasSubmitted;
	}
	public void setIdeasSubmitted(Integer ideasSubmitted) {
		this.ideasSubmitted = ideasSubmitted;
	}
	public Integer getSolvedIn2014A() {
		return solvedIn2014A;
	}
	public void setSolvedIn2014A(Integer solvedIn2014A) {
		this.solvedIn2014A = solvedIn2014A;
	}
	public Integer getClosededIn2014A() {
		return closededIn2014A;
	}
	public void setClosededIn2014A(Integer closededIn2014A) {
		this.closededIn2014A = closededIn2014A;
	}
	public Integer getDuplicateIn2014A() {
		return duplicateIn2014A;
	}
	public void setDuplicateIn2014A(Integer duplicateIn2014A) {
		this.duplicateIn2014A = duplicateIn2014A;
	}
	public Integer getSolvedIn2014B() {
		return solvedIn2014B;
	}
	public void setSolvedIn2014B(Integer solvedIn2014B) {
		this.solvedIn2014B = solvedIn2014B;
	}
	public Integer getClosededIn2014B() {
		return closededIn2014B;
	}
	public void setClosededIn2014B(Integer closededIn2014B) {
		this.closededIn2014B = closededIn2014B;
	}
	public Integer getDuplicateIn2014B() {
		return duplicateIn2014B;
	}
	public void setDuplicateIn2014B(Integer duplicateIn2014B) {
		this.duplicateIn2014B = duplicateIn2014B;
	}
	public Integer getSolvedIn2014C() {
		return solvedIn2014C;
	}
	public void setSolvedIn2014C(Integer solvedIn2014C) {
		this.solvedIn2014C = solvedIn2014C;
	}
	public Integer getClosededIn2014C() {
		return closededIn2014C;
	}
	public void setClosededIn2014C(Integer closededIn2014C) {
		this.closededIn2014C = closededIn2014C;
	}
	public Integer getDuplicateIn2014C() {
		return duplicateIn2014C;
	}
	public void setDuplicateIn2014C(Integer duplicateIn2014C) {
		this.duplicateIn2014C = duplicateIn2014C;
	}
	
	

}
