package com.beingjavaguys.dao;

import java.util.List;

import com.beingjavaguys.domain.Student;
import com.beingjavaguys.domain.Teacher;

public interface UserDao {
	
	public List<Student> getStudentList();

	public List<Teacher> getTeacherList();

}
