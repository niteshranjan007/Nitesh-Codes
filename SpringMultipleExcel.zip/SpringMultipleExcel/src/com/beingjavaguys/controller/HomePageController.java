package com.beingjavaguys.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.beingjavaguys.dao.UserDao;
import com.beingjavaguys.domain.Student;
import com.beingjavaguys.domain.Teacher;

@Controller
public class HomePageController {

	@Autowired
	UserDao userDao;

	
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String viewHome() {
		return "home";
	}
	
	@RequestMapping(value="/downloadExcel", method = RequestMethod.GET)
	public ModelAndView getUserLIst() {
		List<Student> studentList = userDao.getStudentList();
		List<Teacher> teacherList = userDao.getTeacherList();
		Map<String,Object> map= new HashMap<String,Object>(); 
		map.put("student", studentList);
		map.put("teacher", teacherList);
		return new ModelAndView("excelView", "map", map);
	}

}