package com.nitesh;

public class ReverseString {

	  public void reverseWordInMyString(String str)
	   {
		
		char[] words = str.toCharArray();
		
		StringBuilder sb = new StringBuilder();
		
		   for (int j = words.length-1; j >= 0; j--) 
		   {
            sb.append(words[j]);
		   }
		
		System.out.println(str);
		System.out.println(sb.toString());
	   
		   }
		   
		   
	   public static void main(String[] args) 
	   {
		   ReverseString obj = new ReverseString();
		obj.reverseWordInMyString("Beginner11sBook");
	   }
	}